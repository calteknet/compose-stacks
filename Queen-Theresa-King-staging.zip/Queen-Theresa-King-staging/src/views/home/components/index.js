export { default as MusicalOracle } from "./musicalOracle";
export { default as NewMusicRelease } from "./newMusicRelease";
export { default as Offer } from "./offer";
export { default as MusicRevolution } from "./musicRevolution";
export { default as AboutUs } from "./aboutUs";
export { default as SocialMedia } from "./socialMedia";
export { default as ContactUs } from "./contactUs";
